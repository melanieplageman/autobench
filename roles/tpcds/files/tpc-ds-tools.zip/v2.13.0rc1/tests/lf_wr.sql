insert into web_returns (select * from wrv);
rollback;
